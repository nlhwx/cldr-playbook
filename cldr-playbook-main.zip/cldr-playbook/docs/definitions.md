# Example Cluster Definitions

## CDP Private Cloud Base 7.1.x

### Basic

TODO

### "Express Wizard"

These example templates are designed to replicate the options of Cloudera Manager's cluster installation wizard.

- **Data Engineering** (`7.1.1/data-engineering`)

  This template includes a wide range of services.

- **Data Mart** (`7.1.1/data-mart`)

  Includes a more limited range of services, specialising on interactive SQL analysis.

- **Operational Database** (`7.1.1/operational-db`)

  Includes an even more limited range of services, specialising around HBase.

### CDSW

TODO

### Secure

TODO

## CDH 6.3.x

TODO

## CDH 5.16.x

TODO



